/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhozgm;


import java.util.Scanner;

/**
 *
 * @author 15931958690
 */
public class Funcionario {
   
   static Scanner entrada = new Scanner (System.in);
    
    private String nome;
    private String cpf;
   private String codFunc; 
   
   public Funcionario(){
     
   }
   
   public Funcionario (String nome, String cpf, String data){
       this.nome = nome;
       this.cpf = cpf;
   }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCodFunc() {
        return codFunc;
    }

    public void setCodFunc(String codFunc) {
        this.codFunc = codFunc;
    }

   
   
   
     public void cadastrarFuncionario(Funcionario objFuncinario){
        Funcionario novoFuncionario = objFuncinario;
        
        System.out.println("------FUNCIONÁRIOS------");
        
        System.out.println("Nome do Funcionário:   ");
        novoFuncionario.setNome( entrada.next());
        entrada.nextLine();
       
        
        System.out.println("CPF do Funcionário:  ");
        novoFuncionario.setCpf(entrada.nextLine());
        
         System.out.println("Digite o código do funcionário: ");
         novoFuncionario.setCodFunc(entrada.nextLine());
        
        
        System.out.println("Sucesso! Seu novo funcionário foi cadastrado!");
    }
     
     public void mostra(Funcionario objFuncionario, Cliente objCliente, Venda objVenda,VendaCombo simples, ComboSobre combo ){
        
            objCliente.mostrarNome();
            System.out.println("Identificação da venda: " +objVenda.getIdentificacao());
            simples.Venda(0);
            combo.Venda(0);
            
        }
   

}
