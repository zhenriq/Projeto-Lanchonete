/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhozgm;
import java.util.Scanner;
/**
 *
 * @author gcapr
 */
public class VendaCombo extends Venda {
    Scanner venda = new Scanner(System.in);
    

    public VendaCombo(){
    
    }
    
    
     @Override
     public void cadastrarVenda(Venda objVenda){
       // VendaCombo vendas = new VendaCombo ("","",0,0,0);
        System.out.println("---------NOSSOS COMBOS-----------");
        
        System.out.println(" Digite o nome do salgado:   ");
        objVenda.setSalgado(entrada.nextLine());
        System.out.println(" Digite o valor do salgado: ");
        objVenda.setValorSalg(entrada.nextDouble());
        
         System.out.println(" Digite o nome da bebida: ");
         objVenda.setBebida(entrada.next());
         System.out.println(" Digite o valor da bebida: ");
         objVenda.setValorBebida(entrada.nextDouble());
         
        System.out.println("Sucesso! O seu combo foi cadastrado!");
        
     }

    @Override
    public double Venda (double venda){
        this.valorTotal = this.getValorBebida() + this.getValorSalg();
        return valorTotal-1;
    }
    
}
