/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhozgm;

import java.util.Scanner;

/**
 *
 * @author 15931958690
 */
public class Cadastros {
    Scanner entrada = new Scanner (System.in);
        Cliente objCliente = new Cliente();
        Funcionario objFuncionario = new Funcionario();
        Venda objVenda = new Venda();
        VendaCombo simples = new VendaCombo();
        ComboSobre combo = new ComboSobre ();
     
        
        
        public void exibirTeste(){
              while (true){
             System.out.println("-----------------LANCHONETE---------------------");
             System.out.println("| 1- Cadastrar funcionário");
             System.out.println("| 2- Cadastrar cliente");
             System.out.println("| 3- Cadastrar venda");
             System.out.println("| 4- Cadastrar combo simples (salgado+bebida)");
             System.out.println("| 5- Cadastrar combo com sobremesa");
             System.out.println("| 6- Relatório total");
             System.out.println("| 0-Sair");
             System.out.println("Escolha uma das opções acima: ");
             int opcao = entrada.nextInt();
                  
             System.out.println("\n------------------------------");
                  
            switch (opcao){
                 case 0:
                     System.out.println("Programa encerrado........");
                     return;
                     
                 case 1:
                 objFuncionario.cadastrarFuncionario(objFuncionario);
                 break;
             
                 case 2:
                 objCliente.cadastrarCliente();
                 break;
             
                 case 3:
                 objVenda.cadastrarVenda(objVenda);
                 break;
                 
                 case 4:
                 simples.cadastrarVenda(objVenda);
                 break;
                 
                 case 5:
                 combo.cadastrarVenda(objVenda);
                 break;
                 
                 case 6:
                 objFuncionario.mostra(objFuncionario, objCliente, objVenda, simples, combo);
                 break;
                 
             default :
             System.out.println("Opção não encontrada.");
             break;
            
        }
        
    }
}
}

