/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhozgm;


import java.util.Scanner;

/**
 *
 * @author 15931958690
 */
public class Venda {
     Scanner entrada = new Scanner (System.in);
   
    private String identificacao;
    private String vendaPrestado;
    public double valor;
    private String salgado;
    private String bebida;
    private String sobremesa;
    private double valorSobre;
    private double valorSalg;
    private double valorBebida;

    public Venda(){
        
    }
    
    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }
    public String getSalgado() {
        return salgado;
    }

    public void setSalgado(String salgado) {
        this.salgado = salgado;
    }

    public String getBebida() {
        return bebida;
    }

    public void setBebida(String bebida) {
        this.bebida = bebida;
    }

    public double getValorSalg() {
        return valorSalg;
    }

    public void setValorSalg(double valorSalg) {
        this.valorSalg = valorSalg;
    }

    public double getValorBebida() {
        return valorBebida;
    }

    public void setValorBebida(double valorBebida) {
        this.valorBebida = valorBebida;
    }
    
    public String getSobremesa() {
        return sobremesa;
    }

    public void setSobremesa(String sobremesa) {
        this.sobremesa = sobremesa;
    }

    public double getValorSobre() {
        return valorSobre;
    }

    public void setValorSobre(double valorSobre) {
        this.valorSobre = valorSobre;
    }
    
    public double valorTotal;
    
    public Venda (String identificacao, String vendaPrestado, double valor, double valorTotal,
    String salgado, String bebida, double valorSalg, double valorBebida, double valorSobre, String sobremesa){
        this.identificacao = identificacao;
        this.vendaPrestado = vendaPrestado;
        this.valor = valor;
        this.valorTotal = valorTotal; 
        this.bebida = bebida;
        this.salgado = salgado;
        this.valorBebida = valorBebida;
        this.valorSalg = valorSalg;
        this.sobremesa = sobremesa;
        this.valorSobre = valorSobre;
        
    }

    public String getIdentificacao() {
        return identificacao;
    }


    public void setIdentificacao(String identifica) {
        this.identificacao = identifica;
    }

    public String getVendaPrestado() {
        return vendaPrestado;
    }

    public void setVendaPrestado(String vendaPrestado) {
        this.vendaPrestado = vendaPrestado;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
    public void cadastrarVenda(Venda objVenda){
        //Venda venda = new Venda ("","",0,0);
        System.out.println("---------NOSSAS VENDAS-----------");
        
        System.out.println(" Digite o nome do produto:   ");
        objVenda.setVendaPrestado(entrada.nextLine());
        
        System.out.println(" Digite um código de identificação do produto:   ");
        objVenda.setIdentificacao(entrada.nextLine());
        
        System.out.println("Digite o valor do produto: ");
        objVenda.setValor(entrada.nextDouble());
        
     
        System.out.println("Sucesso! O seu produto foi cadastrado!");
    }
    
   public double Venda (double venda){
        this.valorTotal += this.valor;
        return valorTotal;
    }
   
}
