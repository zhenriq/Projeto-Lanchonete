/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhozgm;


import java.util.Scanner;

/**
 *
 * @author 15931958690
 */
public class Cliente {
    Scanner entrada = new Scanner (System.in);
    
    
    private String nome;
    private String telefone;
    private String cpf;
   
    public Cliente(){
        
    }
    
    public Cliente(String nome, String telefone, String cpf){
        this.nome = nome;
        this.telefone = telefone;
        this.cpf = cpf; 
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

   
    public void cadastrarCliente(){       
        System.out.println("---------NOSSOS CLIENTES--------------");
        
        System.out.println("Nome do Cliente:   ");
        setNome( entrada.nextLine());
        
        System.out.println("Telefone do Cliente:   ");
        setTelefone(entrada.nextLine());
        
     
        System.out.println("Sucesso! Seu novo cliente foi cadastrado!");
    }
    
    public void mostrarNome(){
        System.out.println("Nome do cliente: " +this.getNome());
        System.out.println("Telefone do cliente: " +this.getTelefone());
    }    
}

